import { Module } from '@nestjs/common';

import { EmisController } from './emis.controller';
import { EmisService } from './emis.service';

@Module({
  controllers: [EmisController],
  providers: [EmisService],
})
export class EmisModule {}