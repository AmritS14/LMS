import {
  ArrayNotEmpty,
  IsArray,
  IsEnum,
  IsOptional,
  IsString,
} from 'class-validator';

export class RequestDocumentsDto {
  @IsArray()
  @ArrayNotEmpty()
  @IsEnum(
    [
      'pan_card',
      'aadhaar_card',
      'salary_slip',
      'bank_statement',
      'itr',
      'passport_photo',
      'employment_certificate',
      'address_proof',
      'other',
    ],
    { each: true },
  )
  documentTypes: string[];

  @IsOptional()
  @IsString()
  remark?: string;
}