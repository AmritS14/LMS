import {
  IsIn,
  IsOptional,
} from 'class-validator';

export class ApplicationQueryDto {
  @IsOptional()
  @IsIn([
    'draft',
    'assigned',
    'under_review',
    'document_pending',
    'manager_review',
    'approved',
    'rejected',
    'disbursed',
    'closed',
  ])
  status?: string;
}