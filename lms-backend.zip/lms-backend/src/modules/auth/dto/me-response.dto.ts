export class MeResponseDto {
  id: string;

  email: string;

  role: string;

  fullName: string;

  phone?: string;

  mustChangePassword: boolean;

  mfaRequired: boolean;
}