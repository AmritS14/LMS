export type AuthUser = {
  id: string;
  email: string;
  role: 'borrower' | 'loan_officer' | 'manager' | 'admin';
  isActive: boolean;
  mustChangePassword: boolean;
  mfaRequired: boolean;
};