import {
  IsOptional,
  IsString,
} from 'class-validator';

export class VerifyDocumentDto {
  @IsOptional()
  @IsString()
  remark?: string;
}