import {
  IsEnum,
} from 'class-validator';

export class UploadDocumentDto {
  @IsEnum([
    'identityProof',
    'addressProof',
    'incomeProof',
    'bankStatement',
    'collateral',
    'other',
  ])
  kind:
    | 'identityProof'
    | 'addressProof'
    | 'incomeProof'
    | 'bankStatement'
    | 'collateral'
    | 'other';
}