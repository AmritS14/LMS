export function calculateEMI({
  principal,
  annualInterestRate,
  tenureMonths,
}: {
  principal: number;
  annualInterestRate: number;
  tenureMonths: number;
}) {
  const monthlyRate =
    annualInterestRate /
    12 /
    100;

  const emi =
    (principal *
      monthlyRate *
      Math.pow(
        1 + monthlyRate,
        tenureMonths,
      )) /
    (Math.pow(
      1 + monthlyRate,
      tenureMonths,
    ) -
      1);

  return Number(
    emi.toFixed(2),
  );
}

export function generateAmortizationSchedule(
  {
    principal,
    annualInterestRate,
    tenureMonths,
    startDate,
  }: {
    principal: number;
    annualInterestRate: number;
    tenureMonths: number;
    startDate: Date;
  },
) {
  const monthlyRate =
    annualInterestRate /
    12 /
    100;

  const emi = calculateEMI({
    principal,
    annualInterestRate,
    tenureMonths,
  });

  let remainingBalance =
    principal;

  const schedule: {
    installment_number: number;
    due_date: string;
    principal_component: number;
    interest_component: number;
    total_amount: number;
    remaining_balance: number;
  }[] = [];

  for (
    let month = 1;
    month <= tenureMonths;
    month++
  ) {
    const interestComponent =
      Number(
        (
          remainingBalance *
          monthlyRate
        ).toFixed(2),
      );

    const principalComponent =
      Number(
        (
          emi -
          interestComponent
        ).toFixed(2),
      );

    remainingBalance =
      Number(
        (
          remainingBalance -
          principalComponent
        ).toFixed(2),
      );

    const dueDate = new Date(
      startDate,
    );

    dueDate.setMonth(
      dueDate.getMonth() + month,
    );

    schedule.push({
      installment_number:
        month,
      due_date:
        dueDate
          .toISOString()
          .split('T')[0],
      principal_component:
        principalComponent,
      interest_component:
        interestComponent,
      total_amount: emi,
      remaining_balance:
        Math.max(
          remainingBalance,
          0,
        ),
    });
  }

  return schedule;
}