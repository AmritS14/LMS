import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
} from '@nestjs/swagger';

import { ApplicationsService } from './applications.service';

import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';

import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

import type { AuthUser } from '../../common/types/auth-user.type';

import { CreateApplicationDto } from './dto/create-application.dto';
import { UpdateStatusDto } from './dto/update-status.dto';

import { RequestDocumentsDto } from './dto/request-documents.dto';
import { ApplicationQueryDto } from './dto/application-query.dto';
import { DocumentsUploadedDto } from './dto/documents-uploaded.dto';


@ApiTags('Applications')
@ApiBearerAuth()
@Controller('applications')
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
export class ApplicationsController {
  constructor(
    private readonly applicationsService: ApplicationsService,
  ) {}

  @Get('my')
  @Roles('borrower')
  async getMyApplications(
    @CurrentUser() user: AuthUser,
    @Query() query: ApplicationQueryDto,
  ) {
    return this.applicationsService.getBorrowerApplications(
      user.id,
      query.status,
    );
  }

  @Get('assigned')
  @Roles('loan_officer')
  async getAssignedApplications(
    @CurrentUser() user: AuthUser,
    @Query() query: ApplicationQueryDto,
  ) {
    return this.applicationsService.getAssignedApplications(
      user.id,
      query.status,
    );
  }

  @Get(':id')
  async getApplicationDetails(
    @Param('id') id: string,
  ) {
    return this.applicationsService.getApplicationDetails(
      id,
    );
  }

  @Get(':id/events')
  async getApplicationEvents(
    @Param('id') id: string,
  ) {
    return this.applicationsService.getApplicationEvents(
      id,
    );
  }


  @Post()
  @Roles('borrower')
  async createApplication(
    @CurrentUser() user: AuthUser,
    @Body() dto: CreateApplicationDto,
  ) {
    return this.applicationsService.createApplication(
      user.id,
      dto,
    );
  }

  @Post(':id/start-review')
  @Roles('loan_officer')
  async startReview(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.applicationsService.startReview(
      id,
      user.id,
    );
  }

  @Post(':id/request-documents')
  @Roles('loan_officer')
  async requestDocuments(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: RequestDocumentsDto,
  ) {
    return this.applicationsService.requestDocuments(
      id,
      user.id,
      dto.documentTypes,
      dto.remark,
    );
  }

  @Post(':id/documents-uploaded')
  @Roles('borrower')
  async documentsUploaded(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: DocumentsUploadedDto,
  ) {
    return this.applicationsService.documentsUploaded(
      id,
      user.id,
      dto.documentIds,
    );
  }

  @Post(':id/send-to-manager')
  @Roles('loan_officer')
  async sendToManager(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: UpdateStatusDto,
  ) {
    return this.applicationsService.sendToManager(
      id,
      user.id,
      dto.remark,
    );
  }

  @Post(':id/approve')
  @Roles('manager', 'admin')
  async approveApplication(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: UpdateStatusDto,
  ) {
    return this.applicationsService.approveApplication(
      id,
      user.id,
      dto.remark,
    );
  }

  @Post(':id/reject')
  @Roles(
    'loan_officer',
    'manager',
    'admin',
  )
  async rejectApplication(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: UpdateStatusDto,
  ) {
    return this.applicationsService.rejectApplication(
      id,
      user.id,
      dto.remark,
    );
  }
}