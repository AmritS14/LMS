import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiBody,
  ApiBearerAuth,
  ApiConsumes,
  ApiTags,
} from '@nestjs/swagger';

import { FileInterceptor } from '@nestjs/platform-express';

import { memoryStorage } from 'multer';

import { DocumentsService } from './documents.service';

import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';

import { CurrentUser } from '../../common/decorators/current-user.decorator';

import type { AuthUser } from '../../common/types/auth-user.type';

import { UploadDocumentDto } from './dto/upload-document.dto';

import { Roles } from '../../common/decorators/roles.decorator';

import { VerifyDocumentDto } from './dto/verify-document.dto';

import { RejectDocumentDto } from './dto/reject-document.dto';

@ApiTags('Documents')
@ApiBearerAuth()
@Controller('documents')
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
export class DocumentsController {
  constructor(
    private readonly documentsService: DocumentsService,
  ) {}

  @Post('upload')
  @Roles('borrower')
  @UseInterceptors(
    FileInterceptor('file', {
      storage: memoryStorage(),
    }),
  )
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        kind: {
          type: 'string',
          example: 'identityProof',
        },
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  async uploadDocument(
    @CurrentUser() user: AuthUser,
    @UploadedFile()
    file: Express.Multer.File,
    @Body()
    dto: UploadDocumentDto,
  ) {
    return this.documentsService.uploadDocument(
      {
        ownerId: user.id,
        file,
        kind: dto.kind,
      },
    );
  }

  @Get(':id/url')
  async getSignedUrl(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.documentsService.getSignedUrl(
      {
        documentId: id,
        userId: user.id,
        role: user.role,
      },
    );
  }

  @Post(':id/verify')
  @Roles(
    'loan_officer',
    'manager',
    'admin',
  )
  async verifyDocument(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: VerifyDocumentDto,
  ) {
    return this.documentsService.verifyDocument(
      {
        documentId: id,
        verifierId: user.id,
        remark: dto.remark,
      },
    );
  }

  @Post(':id/reject')
  @Roles(
    'loan_officer',
    'manager',
    'admin',
  )
  async rejectDocument(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: RejectDocumentDto,
  ) {
    return this.documentsService.rejectDocument(
      {
        documentId: id,
        verifierId: user.id,
        reason: dto.reason,
      },
    );
  }
}