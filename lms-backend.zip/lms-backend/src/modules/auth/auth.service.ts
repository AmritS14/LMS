import { Injectable, UnauthorizedException } from '@nestjs/common';

import { SupabaseService } from '../../supabase/supabase.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly supabaseService: SupabaseService,
  ) {}

  async getCurrentUserProfile(userId: string) {
    const { data, error } = await this.supabaseService.client
      .from('users')
      .select(`
        id,
        email,
        role,
        full_name,
        phone,
        must_change_password,
        mfa_required
      `)
      .eq('id', userId)
      .single();

    if (error || !data) {
      throw new UnauthorizedException('User not found');
    }

    return {
      id: data.id,
      email: data.email,
      role: data.role,
      fullName: data.full_name,
      phone: data.phone,
      mustChangePassword: data.must_change_password,
      mfaRequired: data.mfa_required,
    };
  }
}