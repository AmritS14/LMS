import {
  IsEmail,
  IsEnum,
  IsOptional,
  IsString,
  IsUUID,
  MinLength,
} from 'class-validator';

export class CreateStaffDto {
  @IsString()
  fullName: string;

  @IsEmail()
  email: string;

  @IsString()
  @MinLength(8)
  temporaryPassword: string;

  @IsEnum([
    'loan_officer',
    'manager',
    'admin',
  ])
  role:
    | 'loan_officer'
    | 'manager'
    | 'admin';

  @IsString()
  employeeId: string;

  @IsOptional()
  @IsString()
  department?: string;

  @IsOptional()
  @IsUUID()
  reportsToId?: string;
}