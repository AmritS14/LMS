import {
  Controller,
  Param,
  Post,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
} from '@nestjs/swagger';

import { LoansService } from './loans.service';

import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';

import { Roles } from '../../common/decorators/roles.decorator';

import { CurrentUser } from '../../common/decorators/current-user.decorator';

import type { AuthUser } from '../../common/types/auth-user.type';

@ApiTags('Loans')
@ApiBearerAuth()
@Controller('loans')
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
export class LoansController {
  constructor(
    private readonly loansService: LoansService,
  ) {}

  @Post(
    'applications/:id/disburse',
  )
  @Roles('manager', 'admin')
  async disburseLoan(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.loansService.disburseLoan(
      {
        applicationId: id,
        actorId: user.id,
      },
    );
  }
}