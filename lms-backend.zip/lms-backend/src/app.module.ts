import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

import { SupabaseModule } from './supabase/supabase.module';

import { AuthModule } from './modules/auth/auth.module';
import { AdminModule } from './modules/admin/admin.module';
import { ApplicationsModule } from './modules/applications/applications.module';
import { DocumentsModule } from './modules/documents/documents.module';
import { LoansModule } from './modules/loans/loans.module';
import { EmisModule } from './modules/emis/emis.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),

    SupabaseModule,

    AuthModule,

    AdminModule,

    ApplicationsModule,

    DocumentsModule,

    LoansModule,

    EmisModule,
  ],
})
export class AppModule {}