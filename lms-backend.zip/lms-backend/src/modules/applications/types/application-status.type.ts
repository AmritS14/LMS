export type ApplicationStatus =
  | 'draft'
  | 'submitted'
  | 'assigned'
  | 'under_review'
  | 'document_pending'
  | 'manager_review'
  | 'approved'
  | 'rejected'
  | 'disbursed'
  | 'closed';