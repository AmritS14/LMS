import {
  IsInt,
  IsNumber,
  IsUUID,
  Min,
} from 'class-validator';

export class CreateApplicationDto {
  @IsUUID()
  loanProductId: string;

  @IsNumber()
  @Min(1)
  requestedAmount: number;

  @IsInt()
  @Min(1)
  tenureMonths: number;
}