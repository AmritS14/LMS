import {
  Controller,
  Param,
  Post,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
} from '@nestjs/swagger';

import { EmisService } from './emis.service';

import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';

import { Roles } from '../../common/decorators/roles.decorator';

import { CurrentUser } from '../../common/decorators/current-user.decorator';

import type { AuthUser } from '../../common/types/auth-user.type';

@ApiTags('Emis')
@ApiBearerAuth()
@Controller('emis')
@UseGuards(
  JwtAuthGuard,
  RolesGuard,
)
export class EmisController {
  constructor(
    private readonly emisService: EmisService,
  ) {}

  @Post(':id/pay')
  @Roles(
    'borrower',
    'admin',
  )
  async payEmi(
    @Param('id') id: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.emisService.payEmi({
      emiId: id,
      actorId: user.id,
    });
  }
}