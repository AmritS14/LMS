import {
  BadRequestException,
  Injectable,
} from '@nestjs/common';

import { randomUUID } from 'crypto';

import { SupabaseService } from '../../supabase/supabase.service';

@Injectable()
export class DocumentsService {
  constructor(
    private readonly supabaseService: SupabaseService,
  ) {}

  async uploadDocument({
    ownerId,
    file,
    kind,
  }: {
    ownerId: string;
    file: Express.Multer.File;
    kind: string;
  }) {
    if (!file) {
      throw new BadRequestException(
        'File required',
      );
    }

    const allowedMimeTypes = [
      'application/pdf',
      'image/jpeg',
      'image/png',
    ];

    if (
      !allowedMimeTypes.includes(
        file.mimetype,
      )
    ) {
      throw new BadRequestException(
        'Invalid file type',
      );
    }

    const maxFileSize =
      10 * 1024 * 1024;

    if (file.size > maxFileSize) {
      throw new BadRequestException(
        'File too large',
      );
    }

    const fileExtension =
      file.originalname.split('.').pop();

    const filePath = `${ownerId}/${randomUUID()}.${fileExtension}`;

    const { error: uploadError } =
      await this.supabaseService.client
        .storage
        .from('loan_documents')
        .upload(
          filePath,
          file.buffer,
          {
            contentType:
              file.mimetype,
            upsert: false,
          },
        );

    if (uploadError) {
      throw new BadRequestException(
        uploadError.message,
      );
    }

    const {
      data,
      error,
    } = await this.supabaseService.client
      .from('loan_documents')
      .insert({
        owner_id: ownerId,
        kind,
        file_name:
          file.originalname,
        remote_url: filePath,
      })
      .select()
      .single();

    if (error || !data) {
      throw new BadRequestException(
        error?.message ||
          'Failed to create document',
      );
    }

    return data;
  }

  async verifyDocument({
    documentId,
    verifierId,
    remark,
  }: {
    documentId: string;
    verifierId: string;
    remark?: string;
  }) {
    const {
      data,
      error,
    } = await this.supabaseService.client
      .from('loan_documents')
      .update({
        status: 'verified',
      })
      .eq('id', documentId)
      .select()
      .single();

    if (error || !data) {
      throw new BadRequestException(
        error?.message ||
          'Failed to verify document',
      );
    }

    await this.supabaseService.client
      .from('audit_entries')
      .insert({
        actor_id: verifierId,
        action: 'verify_document',
        entity_type:
          'loan_document',
        entity_id: documentId,
        metadata: {
          remark,
        },
      });

    return data;
  }

  async rejectDocument({
    documentId,
    verifierId,
    reason,
  }: {
    documentId: string;
    verifierId: string;
    reason: string;
  }) {
    const {
      data,
      error,
    } = await this.supabaseService.client
      .from('loan_documents')
      .update({
        status: 'rejected',
      })
      .eq('id', documentId)
      .select()
      .single();

    if (error || !data) {
      throw new BadRequestException(
        error?.message ||
          'Failed to reject document',
      );
    }

    await this.supabaseService.client
      .from('audit_entries')
      .insert({
        actor_id: verifierId,
        action: 'reject_document',
        entity_type:
          'loan_document',
        entity_id: documentId,
        metadata: {
          reason,
        },
      });

    return data;
  }

  async getSignedUrl({
    documentId,
    userId,
    role,
  }: {
    documentId: string;
    userId: string;
    role: string;
  }) {
    const {
      data: document,
      error,
    } = await this.supabaseService.client
      .from('loan_documents')
      .select(`
        *
      `)
      .eq('id', documentId)
      .single();

    if (error || !document) {
      throw new BadRequestException(
        'Document not found',
      );
    }

    const isOwner =
      document.owner_id === userId;

    if (
      !isOwner &&
      role !== 'admin' &&
      role !== 'loan_officer' &&
      role !== 'manager'
    ) {
      throw new BadRequestException(
        'Access denied',
      );
    }

    const {
      data,
      error: signedUrlError,
    } = await this.supabaseService.client
      .storage
      .from('loan_documents')
      .createSignedUrl(
        document.remote_url,
        60 * 10,
      );

    if (
      signedUrlError ||
      !data
    ) {
      throw new BadRequestException(
        'Failed to generate signed URL',
      );
    }

    return data;
  }
}