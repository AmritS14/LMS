import {
  BadRequestException,
  Injectable,
} from '@nestjs/common';

import { SupabaseService } from '../../supabase/supabase.service';

import { CreateStaffDto } from './dto/create-staff.dto';

@Injectable()
export class AdminService {
  constructor(
    private readonly supabaseService: SupabaseService,
  ) {}

  async createStaff(
    dto: CreateStaffDto,
  ) {
    const {
      data: authUser,
      error: authError,
    } =
      await this.supabaseService.client.auth.admin.createUser({
        email: dto.email,
        password: dto.temporaryPassword,
        email_confirm: true,
      });

    if (authError || !authUser.user) {
      throw new BadRequestException(
        authError?.message ||
          'Failed to create auth user',
      );
    }

    const userId = authUser.user.id;

    const { error: userError } =
      await this.supabaseService.client
        .from('users')
        .update({
          full_name: dto.fullName,
          role: dto.role,
          must_change_password: true,
          mfa_required: true,
        })
        .eq('id', userId);

    if (userError) {
      throw new BadRequestException(
        userError.message,
      );
    }

    const { error: staffError } =
      await this.supabaseService.client
        .from('staff_profiles')
        .insert({
          id: userId,
          employee_id: dto.employeeId,
          department: dto.department,
          reports_to_id: dto.reportsToId,
        });

    if (staffError) {
      throw new BadRequestException(
        staffError.message,
      );
    }

    return {
      success: true,
      userId,
      email: dto.email,
      role: dto.role,
    };
  }
}