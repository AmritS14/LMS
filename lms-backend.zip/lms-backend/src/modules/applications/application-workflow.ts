export const APPLICATION_WORKFLOW = {
  draft: ['submitted'],

  submitted: [
    'assigned',
    'rejected',
  ],

  assigned: [
    'under_review',
    'rejected',
  ],

  under_review: [
    'document_pending',
    'manager_review',
    'rejected',
  ],

  document_pending: [
    'under_review',
    'rejected',
  ],

  manager_review: [
    'approved',
    'rejected',
  ],

  approved: ['disbursed'],

  disbursed: ['closed'],

  rejected: [],

  closed: [],
} as const;

export function isValidTransition(
  fromStatus: string,
  toStatus: string,
) {
  const allowedTransitions =
    APPLICATION_WORKFLOW[
      fromStatus as keyof typeof APPLICATION_WORKFLOW
    ];

  if (!allowedTransitions) {
    return false;
  }

  return allowedTransitions.includes(
    toStatus as never,
  );
}