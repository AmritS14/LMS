import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';

import { ConfigService } from '@nestjs/config';

import {
  createRemoteJWKSet,
  jwtVerify,
} from 'jose';

import { RequestWithUser } from '../types/request-with-user.interface';

import { SupabaseService } from '../../supabase/supabase.service';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly configService: ConfigService,
    private readonly supabaseService: SupabaseService,
  ) {}

  async canActivate(
    context: ExecutionContext,
  ): Promise<boolean> {
    const request = context
      .switchToHttp()
      .getRequest<RequestWithUser>();

    const authHeader =
      request.headers.authorization;

    if (!authHeader?.startsWith('Bearer ')) {
      throw new UnauthorizedException(
        'Missing token',
      );
    }

    const token = authHeader.split(' ')[1];

    try {
      const supabaseUrl =
        this.configService.get<string>(
          'SUPABASE_URL',
        );

      if (!supabaseUrl) {
        throw new UnauthorizedException(
          'Missing Supabase URL',
        );
      }

      const JWKS = createRemoteJWKSet(
        new URL(
          `${supabaseUrl}/auth/v1/.well-known/jwks.json`,
        ),
      );

      const { payload } = await jwtVerify(
        token,
        JWKS,
      );

      const userId = payload.sub;

      if (!userId || typeof userId !== 'string') {
        throw new UnauthorizedException(
          'Invalid token',
        );
      }

      const {
        data: user,
        error,
      } = await this.supabaseService.client
        .from('users')
        .select(`
          id,
          email,
          role,
          is_active,
          must_change_password,
          mfa_required
        `)
        .eq('id', userId)
        .single();

      if (error || !user) {
        throw new UnauthorizedException(
          'User not found',
        );
      }

      if (!user.is_active) {
        throw new UnauthorizedException(
          'Account disabled',
        );
      }

      request.user = {
        id: user.id,
        email: user.email,
        role: user.role,
        isActive: user.is_active,
        mustChangePassword:
          user.must_change_password,
        mfaRequired:
          user.mfa_required,
      };

      return true;
    } catch {
      throw new UnauthorizedException(
        'Invalid token',
      );
    }
  }
}