import {
  BadRequestException,
  Injectable,
} from '@nestjs/common';

import { SupabaseService } from '../../supabase/supabase.service';

import {
  generateAmortizationSchedule,
} from '../../common/utils/finance';

@Injectable()
export class LoansService {
  constructor(
    private readonly supabaseService: SupabaseService,
  ) {}

  async disburseLoan({
    applicationId,
    actorId,
  }: {
    applicationId: string;
    actorId: string;
  }) {
    const {
      data: application,
      error:
        applicationError,
    } = await this.supabaseService.client
      .from('loan_applications')
      .select('*')
      .eq('id', applicationId)
      .single();

    if (
      applicationError ||
      !application
    ) {
      throw new BadRequestException(
        'Application not found',
      );
    }

    if (
      application.status !==
      'approved'
    ) {
      throw new BadRequestException(
        'Application not approved',
      );
    }

    const disbursementDate =
      new Date();

    const {
      data: loan,
      error: loanError,
    } = await this.supabaseService.client
      .from('loans')
      .insert({
        application_id:
          application.id,
        borrower_id:
          application.borrower_id,
        principal:
          application.requested_amount,
        interest_rate:
          application.interest_rate,
        tenure_months:
          application.tenure_months,
        disbursement_date:
          disbursementDate
            .toISOString()
            .split('T')[0],
        outstanding_balance:
          application.requested_amount,
        status: 'active',
      })
      .select()
      .single();

    if (loanError || !loan) {
      throw new BadRequestException(
        loanError?.message ||
          'Failed to create loan',
      );
    }

    const schedule =
      generateAmortizationSchedule(
        {
          principal:
            loan.principal,
          annualInterestRate:
            loan.interest_rate,
          tenureMonths:
            loan.tenure_months,
          startDate:
            disbursementDate,
        },
      );

    const emis = schedule.map(
      (emi) => ({
        loan_id: loan.id,
        installment_number:
          emi.installment_number,
        due_date:
          emi.due_date,
        principal_component:
          emi.principal_component,
        interest_component:
          emi.interest_component,
        total_amount:
          emi.total_amount,
      }),
    );

    const { error: emiError } =
      await this.supabaseService.client
        .from('emis')
        .insert(emis);

    if (emiError) {
      throw new BadRequestException(
        emiError.message,
      );
    }

    await this.supabaseService.client
      .from('loan_application_events')
      .insert({
        application_id:
          application.id,
        actor_id: actorId,
        event_type:
          'disbursed',
        from_status:
          'approved',
        to_status:
          'disbursed',
      });

    await this.supabaseService.client
      .from('loan_applications')
      .update({
        status: 'disbursed',
      })
      .eq('id', application.id);

    return {
      loan,
      emiCount:
        schedule.length,
    };
  }
}