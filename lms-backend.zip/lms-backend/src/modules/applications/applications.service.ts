import {
  BadRequestException,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';

import { SupabaseService } from '../../supabase/supabase.service';

import { isValidTransition } from './application-workflow';
import { CreateApplicationDto } from './dto/create-application.dto';

@Injectable()
export class ApplicationsService {
  constructor(
    private readonly supabaseService: SupabaseService,
  ) {}

  async createApplication(
    borrowerId: string,
    dto: CreateApplicationDto,
  ) {
    const officerId =
      await this.findBestOfficer();

    const {
        data: loanProduct,
        error: loanProductError,
    } = await this.supabaseService.client
        .from('loan_products')
        .select(`
            minimum_interest_rate
        `)
        .eq('id', dto.loanProductId)
        .single();

    if (
        loanProductError ||
        !loanProduct
    ) {
        throw new BadRequestException(
            'Invalid loan product',
        );
    }

    const interestRate =
        loanProduct.minimum_interest_rate;

    const { data, error } =
      await this.supabaseService.client
        .from('loan_applications')
        .insert({
          borrower_id: borrowerId,
          loan_product_id:
            dto.loanProductId,
          requested_amount:
            dto.requestedAmount,
          tenure_months:
            dto.tenureMonths,
          assigned_officer_id:
            officerId,
          interest_rate:
            interestRate,
          status: 'assigned',
        })
        .select()
        .single();

    if (error || !data) {
      throw new BadRequestException(
        error?.message ||
          'Failed to create application',
      );
    }

    await this.createEvent({
      applicationId: data.id,
      eventType: 'submitted',
      actorId: borrowerId,
    });

    await this.createEvent({
      applicationId: data.id,
      eventType: 'auto_assigned',
      actorId: borrowerId,
      metadata: {
        officerId,
      },
    });

    return data;
  }

  async startReview(
    applicationId: string,
    officerId: string,
  ) {
    const application =
      await this.getApplication(
        applicationId,
      );

    if (
      application.assigned_officer_id !==
      officerId
    ) {
      throw new ForbiddenException(
        'Not assigned officer',
      );
    }

    await this.transitionStatus({
      applicationId,
      actorId: officerId,
      fromStatus:
        application.status,
      toStatus: 'under_review',
      eventType: 'review_started',
    });

    return {
      success: true,
    };
  }

  async requestDocuments(
    applicationId: string,
    officerId: string,
    documentTypes: string[],
    remark?: string,
    ) {
    const application =
        await this.getApplication(
        applicationId,
        );

    if (
        application.assigned_officer_id !==
        officerId
    ) {
        throw new ForbiddenException(
        'Not assigned officer',
        );
    }

    await this.transitionStatus({
        applicationId,
        actorId: officerId,
        fromStatus:
        application.status,
        toStatus: 'document_pending',
        eventType:
        'document_requested',
        remark,
    });

    await this.createEvent({
        applicationId,
        actorId: officerId,
        eventType:
        'document_requested',
        metadata: {
        requestedDocuments:
            documentTypes,
        },
    });

    return {
        success: true,
    };
  }

  async documentsUploaded(
    applicationId: string,
    borrowerId: string,
    documentIds: string[],
    ) {
    const application =
        await this.getApplication(
        applicationId,
        );

    if (
        application.borrower_id !==
        borrowerId
    ) {
        throw new ForbiddenException(
        'Not application owner',
        );
    }

    await this.transitionStatus({
        applicationId,
        actorId: borrowerId,
        fromStatus:
        application.status,
        toStatus: 'under_review',
        eventType:
        'documents_uploaded',
    });

    for (const documentId of documentIds) {
        const { error } =
        await this.supabaseService.client
            .from(
            'loan_application_documents',
            )
            .insert({
            application_id:
                applicationId,
            document_id:
                documentId,
            });

        if (error) {
        throw new BadRequestException(
            error.message,
        );
        }
    }

    return {
        success: true,
    };
    }

  async sendToManager(
    applicationId: string,
    officerId: string,
    remark?: string,
  ) {
    const application =
      await this.getApplication(
        applicationId,
      );

    if (
      application.assigned_officer_id !==
      officerId
    ) {
      throw new ForbiddenException(
        'Not assigned officer',
      );
    }

    await this.transitionStatus({
      applicationId,
      actorId: officerId,
      fromStatus:
        application.status,
      toStatus: 'manager_review',
      eventType: 'sent_to_manager',
      remark,
    });

    return {
      success: true,
    };
  }

  async approveApplication(
    applicationId: string,
    managerId: string,
    remark?: string,
  ) {
    const application =
      await this.getApplication(
        applicationId,
      );

    await this.transitionStatus({
      applicationId,
      actorId: managerId,
      fromStatus:
        application.status,
      toStatus: 'approved',
      eventType: 'approved',
      remark,
    });

    return {
      success: true,
    };
  }

  async rejectApplication(
    applicationId: string,
    actorId: string,
    remark?: string,
  ) {
    const application =
      await this.getApplication(
        applicationId,
      );

    await this.transitionStatus({
      applicationId,
      actorId,
      fromStatus:
        application.status,
      toStatus: 'rejected',
      eventType: 'rejected',
      remark,
    });

    return {
      success: true,
    };
  }

  async getBorrowerApplications(
    borrowerId: string,
    status?: string,
  ) {
    let query =
      this.supabaseService.client
        .from('loan_applications')
        .select(`
          *,
          loan_products (
            id,
            name
          )
        `)
        .eq('borrower_id', borrowerId)
        .order('created_at', {
          ascending: false,
        });

    if (status) {
      query = query.eq(
        'status',
        status,
      );
    }

    const { data, error } =
      await query;

    if (error) {
      throw new BadRequestException(
        error.message,
      );
    }

  return data;
}

async getAssignedApplications(
  officerId: string,
  status?: string,
) {
  let query =
    this.supabaseService.client
      .from('loan_applications')
      .select(`
        *,
        users!loan_applications_borrower_id_fkey (
          id,
          full_name,
          email
        ),
        loan_products (
          id,
          name
        )
      `)
      .eq(
        'assigned_officer_id',
        officerId,
      )
      .order('created_at', {
        ascending: false,
      });

  if (status) {
    query = query.eq(
      'status',
      status,
    );
  }

  const { data, error } =
    await query;

  if (error) {
    throw new BadRequestException(
      error.message,
    );
  }

  return data;
}

async getApplicationDetails(
  applicationId: string,
) {
  const { data, error } =
    await this.supabaseService.client
      .from('loan_applications')
      .select(`
        *,
        users!loan_applications_borrower_id_fkey (
          id,
          full_name,
          email
        ),
        loan_products (
          id,
          name
        )
      `)
      .eq('id', applicationId)
      .single();

  if (error || !data) {
    throw new BadRequestException(
      'Application not found',
    );
  }

  return data;
}

async getApplicationEvents(
  applicationId: string,
) {
  const { data, error } =
    await this.supabaseService.client
      .from('loan_application_events')
      .select(`
        *
      `)
      .eq(
        'application_id',
        applicationId,
      )
      .order('created_at', {
        ascending: true,
      });

    if (error) {
      throw new BadRequestException(
        error.message,
      );
    }

    return data;
  }

  private async getApplication(
    applicationId: string,
  ) {
    const { data, error } =
      await this.supabaseService.client
        .from('loan_applications')
        .select('*')
        .eq('id', applicationId)
        .single();

    if (error || !data) {
      throw new BadRequestException(
        'Application not found',
      );
    }

    return data;
  }

  private async findBestOfficer() {
    const { data, error } =
      await this.supabaseService.client
        .from('users')
        .select(`
          id,
          role
        `)
        .eq('role', 'loan_officer')
        .limit(1);

    if (
      error ||
      !data ||
      data.length === 0
    ) {
      throw new BadRequestException(
        'No officers available',
      );
    }

    return data[0].id;
  }

  private async transitionStatus({
    applicationId,
    actorId,
    fromStatus,
    toStatus,
    eventType,
    remark,
  }: {
    applicationId: string;
    actorId: string;
    fromStatus: string;
    toStatus: string;
    eventType: string;
    remark?: string;
  }) {
    const validTransition =
    isValidTransition(
        fromStatus,
        toStatus,
    );

    if (!validTransition) {
    throw new BadRequestException(
        `Invalid transition from ${fromStatus} to ${toStatus}`,
    );
    }
    const { error } =
      await this.supabaseService.client
        .from('loan_applications')
        .update({
          status: toStatus,
        })
        .eq('id', applicationId);

    if (error) {
      throw new BadRequestException(
        error.message,
      );
    }

    await this.createEvent({
      applicationId,
      actorId,
      eventType,
      remark,
      fromStatus,
      toStatus,
    });
  }

  private async createEvent({
    applicationId,
    actorId,
    eventType,
    remark,
    metadata,
    fromStatus,
    toStatus,
  }: {
    applicationId: string;
    actorId: string;
    eventType: string;
    remark?: string;
    metadata?: Record<
      string,
      unknown
    >;
    fromStatus?: string;
    toStatus?: string;
  }) {
    const { error } =
      await this.supabaseService.client
        .from('loan_application_events')
        .insert({
          application_id:
            applicationId,
          actor_id: actorId,
          event_type: eventType,
          remark,
          metadata:
            metadata || {},
          from_status:
            fromStatus,
          to_status: toStatus,
        });

    if (error) {
      throw new BadRequestException(
        error.message,
      );
    }
  }
}