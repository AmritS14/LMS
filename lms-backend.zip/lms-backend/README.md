---
title: LMS Backend
emoji: 🚀
colorFrom: blue
colorTo: green
sdk: docker
pinned: false
---

# LMS Backend API

Loan Management System backend using:
- NestJS
- Supabase
- Swagger
- JWT Auth
