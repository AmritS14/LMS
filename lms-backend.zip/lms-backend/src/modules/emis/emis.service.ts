import {
  BadRequestException,
  Injectable,
} from '@nestjs/common';

import { SupabaseService } from '../../supabase/supabase.service';

@Injectable()
export class EmisService {
  constructor(
    private readonly supabaseService: SupabaseService,
  ) {}

  async payEmi({
    emiId,
    actorId,
  }: {
    emiId: string;
    actorId: string;
  }) {
    const {
      data: emi,
      error: emiError,
    } = await this.supabaseService.client
      .from('emis')
      .select('*')
      .eq('id', emiId)
      .single();

    if (emiError || !emi) {
      throw new BadRequestException(
        'EMI not found',
      );
    }

    if (emi.status === 'paid') {
      throw new BadRequestException(
        'EMI already paid',
      );
    }

    const {
      data: updatedEmi,
      error: updateError,
    } = await this.supabaseService.client
      .from('emis')
      .update({
        status: 'paid',
        paid_at:
          new Date().toISOString(),
      })
      .eq('id', emiId)
      .select()
      .single();

    if (
      updateError ||
      !updatedEmi
    ) {
      throw new BadRequestException(
        'Failed to update EMI',
      );
    }

    const {
      data: loan,
      error: loanError,
    } = await this.supabaseService.client
      .from('loans')
      .select('*')
      .eq('id', emi.loan_id)
      .single();

    if (loanError || !loan) {
      throw new BadRequestException(
        'Loan not found',
      );
    }

    const newBalance =
      Number(
        (
          loan.outstanding_balance -
          emi.principal_component
        ).toFixed(2),
      );

    const loanClosed =
      newBalance <= 0;

    const {
      data: updatedLoan,
      error:
        updateLoanError,
    } = await this.supabaseService.client
      .from('loans')
      .update({
        outstanding_balance:
          Math.max(
            newBalance,
            0,
          ),
        status: loanClosed
          ? 'closed'
          : 'active',
      })
      .eq('id', loan.id)
      .select()
      .single();

    if (
      updateLoanError ||
      !updatedLoan
    ) {
      throw new BadRequestException(
        'Failed to update loan',
      );
    }

    await this.supabaseService.client
      .from('audit_entries')
      .insert({
        actor_id: actorId,
        action: 'pay_emi',
        entity_type: 'emi',
        entity_id: emi.id,
        metadata: {
          amount:
            emi.total_amount,
          principal_component:
            emi.principal_component,
          interest_component:
            emi.interest_component,
        },
      });

    return {
      emi: updatedEmi,
      loan: updatedLoan,
    };
  }
}